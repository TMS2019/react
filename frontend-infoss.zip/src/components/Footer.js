import React from 'react'

const Footer = () => {
    return (
        <div className='container mt-5 box'>
            <footer className="footer">
                <span className="text-muted">Infoss - Booking Confirmation 2022</span>
            </footer>
        </div>
    )
}

export default Footer
