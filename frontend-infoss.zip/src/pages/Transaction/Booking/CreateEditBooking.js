import React from 'react'


const CreateEditBooking = () => {


    return (
        <>
        <h2>Create Edit Booking Confirmation</h2>
        </>
    )
}

export default CreateEditBooking