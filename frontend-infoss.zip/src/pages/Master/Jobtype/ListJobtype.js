import React from 'react'

const ListJobtype = () => {
  return (
    <div>ListJobtype</div>
  )
}

export default ListJobtype