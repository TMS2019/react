import React from 'react'

const ListContinent = () => {
  return (
    <div>ListContinent</div>
  )
}

export default ListContinent